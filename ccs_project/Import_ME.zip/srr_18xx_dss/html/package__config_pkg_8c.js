var package__config_pkg_8c =
[
    [ "__xdc_PKGNAME", "package__config_pkg_8c.html#af4620743df11cbb00fb0c9a0aac0ce58", null ],
    [ "__xdc_PKGPREFIX", "package__config_pkg_8c.html#aa16b349b2f66bce346494c11989b5932", null ],
    [ "__xdc_PKGVERS", "package__config_pkg_8c.html#aeb4fc4df848b67e50f8156a3da07b739", null ],
    [ "configPkg__dummy__", "package__config_pkg_8c.html#ae105e4ff50296514835f172425388e53", null ]
];