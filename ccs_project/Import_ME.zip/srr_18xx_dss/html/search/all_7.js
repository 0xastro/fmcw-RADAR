var searchData=
[
  ['gcyclelog_398',['gCycleLog',['../dss__data__path_8c.html#a6e08c5e3199213090b427bdef632f159',1,'gCycleLog():&#160;dss_main.c'],['../dss__main_8c.html#a6e08c5e3199213090b427bdef632f159',1,'gCycleLog():&#160;dss_main.c']]],
  ['gen_5ftwiddle_5ffft16x16_399',['gen_twiddle_fft16x16',['../gen__twiddle__fft16x16_8c.html#a38e8fab357aaee9a221afb8f41ac03fb',1,'gen_twiddle_fft16x16.c']]],
  ['gen_5ftwiddle_5ffft16x16_2ec_400',['gen_twiddle_fft16x16.c',['../gen__twiddle__fft16x16_8c.html',1,'']]],
  ['gen_5ftwiddle_5ffft16x16_2ed_401',['gen_twiddle_fft16x16.d',['../gen__twiddle__fft16x16_8d.html',1,'']]],
  ['gen_5ftwiddle_5ffft32x32_402',['gen_twiddle_fft32x32',['../gen__twiddle__fft32x32_8c.html#a4836a40b1674e69ef29f9745954ffa10',1,'gen_twiddle_fft32x32.c']]],
  ['gen_5ftwiddle_5ffft32x32_2ec_403',['gen_twiddle_fft32x32.c',['../gen__twiddle__fft32x32_8c.html',1,'']]],
  ['gen_5ftwiddle_5ffft32x32_2ed_404',['gen_twiddle_fft32x32.d',['../gen__twiddle__fft32x32_8d.html',1,'']]],
  ['ghsram_405',['gHSRAM',['../dss__main_8c.html#a7c106429088ea25d365cdaa699a62c58',1,'dss_main.c']]],
  ['gmcb_406',['gMCB',['../mm_wave___x_s_s_8h.html#a400857e2ff108c7f9aa2f123e85774a1',1,'gMCB():&#160;dss_main.c'],['../dss__data__path_8c.html#a400857e2ff108c7f9aa2f123e85774a1',1,'gMCB():&#160;dss_main.c'],['../dss__main_8c.html#a400857e2ff108c7f9aa2f123e85774a1',1,'gMCB():&#160;dss_main.c']]],
  ['gmmwl1_407',['gMmwL1',['../dss__data__path_8c.html#abc9873a24b3a8b2d28730047f7ee1115',1,'dss_data_path.c']]],
  ['gmmwl2_408',['gMmwL2',['../dss__data__path_8c.html#af32cc72c66cc0e30a4b5663c2fd1485c',1,'dss_data_path.c']]],
  ['gmmwl3_409',['gMmwL3',['../dss__data__path_8c.html#a04d331bc79664cb2ff72e328f4566d97',1,'dss_data_path.c']]],
  ['guardlen_410',['guardLen',['../struct_mmw_demo___cfar_cfg__t.html#ad06ee845363826fe752e8dcc6c7147e4',1,'MmwDemo_CfarCfg_t']]],
  ['guimonsel_411',['guiMonSel',['../struct_mmw_demo___cli_cfg__t__.html#a2dde618cc1f4afe8362cae238a3df2d3',1,'MmwDemo_CliCfg_t_']]]
];
