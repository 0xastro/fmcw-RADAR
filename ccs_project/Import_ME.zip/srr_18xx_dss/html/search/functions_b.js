var searchData=
[
  ['quadraticinterpfltpeakloc_2860',['quadraticInterpFltPeakLoc',['../dss__data__path_8c.html#a3229ef73ab254e17edbe5dcadfd23fb6',1,'quadraticInterpFltPeakLoc(float *restrict y, int32_t len, int32_t indx):&#160;dss_data_path.c'],['../dss__data__path_8h.html#a3229ef73ab254e17edbe5dcadfd23fb6',1,'quadraticInterpFltPeakLoc(float *restrict y, int32_t len, int32_t indx):&#160;dss_data_path.c']]],
  ['quadraticinterplog2shortpeakloc_2861',['quadraticInterpLog2ShortPeakLoc',['../dss__data__path_8c.html#a2d8a872aba73fe08fe0d817a2a4011da',1,'dss_data_path.c']]]
];
