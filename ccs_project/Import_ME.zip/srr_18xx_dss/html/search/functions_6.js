var searchData=
[
  ['gen_5ftwiddle_5ffft16x16_2803',['gen_twiddle_fft16x16',['../gen__twiddle__fft16x16_8c.html#a38e8fab357aaee9a221afb8f41ac03fb',1,'gen_twiddle_fft16x16.c']]],
  ['gen_5ftwiddle_5ffft32x32_2804',['gen_twiddle_fft32x32',['../gen__twiddle__fft32x32_8c.html#a4836a40b1674e69ef29f9745954ffa10',1,'gen_twiddle_fft32x32.c']]]
];
