var searchData=
[
  ['snrthresholds_2628',['SNRThresholds',['../struct_s_n_r_thresholds.html',1,'']]]
];
