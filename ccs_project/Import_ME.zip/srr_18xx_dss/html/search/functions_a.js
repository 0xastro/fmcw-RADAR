var searchData=
[
  ['parkingassistinit_2855',['parkingAssistInit',['../dss__data__path_8c.html#a4c732c3ef40edafbfdd43c129bb0d47d',1,'parkingAssistInit(DSS_DataPathObj *obj):&#160;dss_data_path.c'],['../dss__data__path_8h.html#a4c732c3ef40edafbfdd43c129bb0d47d',1,'parkingAssistInit(DSS_DataPathObj *obj):&#160;dss_data_path.c']]],
  ['populateoutputs_2856',['populateOutputs',['../dss__data__path_8c.html#a2f1dc419540f889de74a72c297de3c0b',1,'populateOutputs(DSS_DataPathObj *obj):&#160;dss_data_path.c'],['../dss__data__path_8h.html#a2f1dc419540f889de74a72c297de3c0b',1,'populateOutputs(DSS_DataPathObj *obj):&#160;dss_data_path.c']]],
  ['prunetopeaks_2857',['pruneToPeaks',['../dss__data__path_8c.html#afaf7898b45f97cd4862488d583701396',1,'dss_data_path.c']]],
  ['prunetopeaksorneighbourofpeaks_2858',['pruneToPeaksOrNeighbourOfPeaks',['../dss__data__path_8c.html#a77683113772db692e2e692d08e58a0e5',1,'dss_data_path.c']]],
  ['prunetrackinginput_2859',['pruneTrackingInput',['../dss__data__path_8c.html#af07291cd51c3616525a8f08ed40b14fe',1,'pruneTrackingInput(trackingInputReport_t *trackingInput, uint32_t numCluster):&#160;dss_data_path.c'],['../dss__data__path_8h.html#af07291cd51c3616525a8f08ed40b14fe',1,'pruneTrackingInput(trackingInputReport_t *trackingInput, uint32_t numCluster):&#160;dss_data_path.c']]]
];
