var searchData=
[
  ['qelem_936',['qElem',['../structti__sysbios__knl___task___object____.html#a6622e875923fef13dbd481e2da5d7488',1,'ti_sysbios_knl_Task_Object__']]],
  ['quadraticinterpfltpeakloc_937',['quadraticInterpFltPeakLoc',['../dss__data__path_8c.html#a3229ef73ab254e17edbe5dcadfd23fb6',1,'quadraticInterpFltPeakLoc(float *restrict y, int32_t len, int32_t indx):&#160;dss_data_path.c'],['../dss__data__path_8h.html#a3229ef73ab254e17edbe5dcadfd23fb6',1,'quadraticInterpFltPeakLoc(float *restrict y, int32_t len, int32_t indx):&#160;dss_data_path.c']]],
  ['quadraticinterplog2shortpeakloc_938',['quadraticInterpLog2ShortPeakLoc',['../dss__data__path_8c.html#a2d8a872aba73fe08fe0d817a2a4011da',1,'dss_data_path.c']]]
];
