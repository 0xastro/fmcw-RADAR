var searchData=
[
  ['gen_5ftwiddle_5ffft16x16_2ec_2734',['gen_twiddle_fft16x16.c',['../gen__twiddle__fft16x16_8c.html',1,'']]],
  ['gen_5ftwiddle_5ffft16x16_2ed_2735',['gen_twiddle_fft16x16.d',['../gen__twiddle__fft16x16_8d.html',1,'']]],
  ['gen_5ftwiddle_5ffft32x32_2ec_2736',['gen_twiddle_fft32x32.c',['../gen__twiddle__fft32x32_8c.html',1,'']]],
  ['gen_5ftwiddle_5ffft32x32_2ed_2737',['gen_twiddle_fft32x32.d',['../gen__twiddle__fft32x32_8d.html',1,'']]]
];
