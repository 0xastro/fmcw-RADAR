var dss__mrr__pe674_8h =
[
    [ "heap0", "dss__mrr__pe674_8h.html#a8792d52f59ca3906d10342e5dea79d53", null ],
    [ "xdc_runtime_Startup__EXECFXN__C", "dss__mrr__pe674_8h.html#aae56c6407c4a5bd12366def52c154958", null ],
    [ "xdc_runtime_Startup__RESETFXN__C", "dss__mrr__pe674_8h.html#a798a413488a31de09f86ee0dd3f2d7fb", null ]
];