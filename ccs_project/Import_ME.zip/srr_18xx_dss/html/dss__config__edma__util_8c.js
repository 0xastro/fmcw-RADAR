var dss__config__edma__util_8c =
[
    [ "MAX", "dss__config__edma__util_8c.html#aacc3ee1a7f283f8ef65cea31f4436a95", null ],
    [ "EDMA_setup_shadow_link", "dss__config__edma__util_8c.html#a53794c0681c33b0edc0048f899640661", null ],
    [ "EDMAutil_configType1", "dss__config__edma__util_8c.html#a150f2630da81f8aff78617b093f71a91", null ],
    [ "EDMAutil_configType2a", "dss__config__edma__util_8c.html#ae85cd3acee5a1a6cafc9220e4bb76a51", null ],
    [ "EDMAutil_configType2b", "dss__config__edma__util_8c.html#a78e519796d3ee3f89db452c3f22ee6e6", null ],
    [ "EDMAutil_configType3", "dss__config__edma__util_8c.html#a64366456ee6eb7aa4cd11cb71ace36c5", null ],
    [ "EDMAutil_triggerType3", "dss__config__edma__util_8c.html#a1c927064bc77548e24ad97b91df3186a", null ]
];