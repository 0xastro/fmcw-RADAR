var gen__twiddle__fft32x32_8c =
[
    [ "PI", "gen__twiddle__fft32x32_8c.html#a598a3330b3c21701223ee0ca14316eca", null ],
    [ "d2i", "gen__twiddle__fft32x32_8c.html#a5a03aeff5019c5ab63dbd4f4aab8b67a", null ],
    [ "gen_twiddle_fft32x32", "gen__twiddle__fft32x32_8c.html#a4836a40b1674e69ef29f9745954ffa10", null ]
];