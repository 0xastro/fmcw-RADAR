var modules =
[
    [ "EDMA Allocation.", "group___m_r_r.html", "group___m_r_r" ]
];