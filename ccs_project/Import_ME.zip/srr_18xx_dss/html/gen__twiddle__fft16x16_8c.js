var gen__twiddle__fft16x16_8c =
[
    [ "PI", "gen__twiddle__fft16x16_8c.html#a598a3330b3c21701223ee0ca14316eca", null ],
    [ "d2s", "gen__twiddle__fft16x16_8c.html#a3d37219f65a0c7cdc2b0fd4c2168543f", null ],
    [ "gen_twiddle_fft16x16", "gen__twiddle__fft16x16_8c.html#a38e8fab357aaee9a221afb8f41ac03fb", null ]
];