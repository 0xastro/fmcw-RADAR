var globals_func =
[
    [ "_", "globals_func.html", null ],
    [ "a", "globals_func_a.html", null ],
    [ "c", "globals_func_c.html", null ],
    [ "d", "globals_func_d.html", null ],
    [ "e", "globals_func_e.html", null ],
    [ "f", "globals_func_f.html", null ],
    [ "g", "globals_func_g.html", null ],
    [ "i", "globals_func_i.html", null ],
    [ "k", "globals_func_k.html", null ],
    [ "m", "globals_func_m.html", null ],
    [ "p", "globals_func_p.html", null ],
    [ "q", "globals_func_q.html", null ],
    [ "r", "globals_func_r.html", null ],
    [ "s", "globals_func_s.html", null ],
    [ "t", "globals_func_t.html", null ],
    [ "x", "globals_func_x.html", null ]
];