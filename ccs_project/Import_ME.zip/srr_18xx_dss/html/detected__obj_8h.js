var detected__obj_8h =
[
    [ "MmwDemo_detectedObj_t", "struct_mmw_demo__detected_obj__t.html", "struct_mmw_demo__detected_obj__t" ],
    [ "DOPPLER_IDX_TO_SIGNED", "detected__obj_8h.html#aadbe88483d7d17cf1e18bd38cb3c25b1", null ],
    [ "DOPPLER_IDX_TO_UNSIGNED", "detected__obj_8h.html#a558eb0a31417d1363eccfc369557b197", null ],
    [ "MMW_MAX_OBJ_OUT", "detected__obj_8h.html#aacb091770bbe78cbd1ea4a03d8145468", null ],
    [ "MmwDemo_detectedObj", "detected__obj_8h.html#a6e34f7ff05ea4a17f897aa9bae35f62d", null ]
];