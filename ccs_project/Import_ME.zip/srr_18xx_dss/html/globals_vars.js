var globals_vars =
[
    [ "_", "globals_vars.html", null ],
    [ "c", "globals_vars_c.html", null ],
    [ "g", "globals_vars_g.html", null ],
    [ "h", "globals_vars_h.html", null ],
    [ "t", "globals_vars_t.html", null ],
    [ "x", "globals_vars_x.html", null ]
];