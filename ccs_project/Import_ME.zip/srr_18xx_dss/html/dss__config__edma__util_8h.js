var dss__config__edma__util_8h =
[
    [ "EDMAutil_configType1", "dss__config__edma__util_8h.html#a150f2630da81f8aff78617b093f71a91", null ],
    [ "EDMAutil_configType2a", "dss__config__edma__util_8h.html#ae85cd3acee5a1a6cafc9220e4bb76a51", null ],
    [ "EDMAutil_configType3", "dss__config__edma__util_8h.html#a64366456ee6eb7aa4cd11cb71ace36c5", null ],
    [ "EDMAutil_triggerType3", "dss__config__edma__util_8h.html#a1c927064bc77548e24ad97b91df3186a", null ]
];